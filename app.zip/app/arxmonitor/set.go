/*
 * @Author: rayou
 * @Date: 2019-04-30 23:17:03
 * @Last Modified by: rayou
 * @Last Modified time: 2019-05-01 12:21:58
 */
package arxmonitor

const (
	DEFAULT_MONITOR_TIME_INTERVAL = 5 // 监控时间精度，单位 s
)
