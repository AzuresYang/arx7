/*
 * @Author: rayou
 * @Date: 2019-04-02 21:57:40
 * @Last Modified by: rayou
 * @Last Modified time: 2019-04-15 16:16:43
 */

package status

const (
	RUN = iota
	STOP
)
