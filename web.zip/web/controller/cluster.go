/*
 * @Author: rayou
 * @Date: 2019-04-27 16:01:21
 * @Last Modified by: rayou
 * @Last Modified time: 2019-05-05 21:57:55
 */
package controller

import (
	"encoding/json"
	"fmt"
	"net/http"

	"github.com/AzuresYang/arx7/arxdeployment"
	_ "github.com/go-sql-driver/mysql"
	log "github.com/sirupsen/logrus"
)

func ClusterHandlerGetPods(response http.ResponseWriter, request *http.Request) {
	log.Infof("Get pods Conn. Form:%#v", request.Form)

	pod1 := ClusterInfo{
		SpiderName: "spider01",
		NodeStatus: "1/1",
		RunStatus:  "Running",
		Age:        "6d",
		NodeAddr:   "127.0.0.1",
		Desc:       "desc",
	}
	pod2 := pod1
	pod2.SpiderName = "spider002"
	cluster_infos := []ClusterInfo{pod1, pod2}
	jdata, _ := json.Marshal(cluster_infos)
	log.Infof("response pods data")
	fmt.Fprintf(response, string(jdata))
}

// 获取爬虫状态
func ClusterHandlerGetSpiderStatus(response http.ResponseWriter, request *http.Request) {
	code_info := "Cluster.GetSpiderStatus"
	request.ParseForm()
	log.Infof("Conn Spider status. Form:%#v", request.Form)
	form := parseFormAsMap(request)
	spider_name := form["spidername"]
	if spider_name == "" {
		log.Errorf("[%s]参数不能为空", code_info)
		responseJson(response, 1, "参数不能为空", "")
		return
	}
	nodes := arxdeployment.GetSpiderNodes(spider_name)
	if len(nodes) <= 0 {
		log.Errorf("[%s]没有该爬虫的部署信息:%s", code_info, spider_name)
		responseJson(response, 0, "没有该爬虫的部署信息："+spider_name, "")
		return
	}
	ret_map := arxdeployment.DoGetSpiderStatusByNodes(nodes)
	ret_msg := "Get Status Ret:"
	for node, msg := range ret_map {
		ret_msg = fmt.Sprintf("%s\n[%s]:%s", ret_msg, node, msg)
	}
	log.Infof("[%s]get status ret:%s", code_info, ret_msg)
	err := responseJson(response, 0, "succ", ret_msg)
	if err != nil {
		log.Errorf("[monitorInfoHandler] response err:%s", err.Error())
	}
}

// 部署爬虫
func ClusterHandlerDeployment(response http.ResponseWriter, request *http.Request) {
	request.ParseForm()
	log.Infof("Conn Deployment. Form:%#v", request.Form)

	pod1 := ClusterInfo{
		SpiderName: "scale",
		NodeStatus: "1/1",
		RunStatus:  "Running",
		Age:        "6d",
		NodeAddr:   "123456",
		Desc:       "is running",
	}
	cluster_infos := []ClusterInfo{pod1}
	err := responseJson(response, 0, "succ", cluster_infos)
	if err != nil {
		log.Errorf("[monitorInfoHandler] response err:%s", err.Error())
	}
}

// 启动爬虫
func ClusterHandlerStartSpider(response http.ResponseWriter, request *http.Request) {
	request.ParseForm()
	code_info := "CusterHandler.StartSpider"
	log.Infof("Conn Start Spider. Form:%#v", request.Form)
	if uploadFile, uploadHeader, err := request.FormFile("config"); err != nil {
		log.Error("[Custer.StartSpider]get config file fail.")
	} else {
		log.Infof("[%s]config filename:%s", code_info, uploadHeader.Filename)
		uploadFile.Close()
	}
	pod1 := ClusterInfo{
		SpiderName: "scale",
		NodeStatus: "1/1",
		RunStatus:  "Running",
		Age:        "6d",
		NodeAddr:   "123456",
		Desc:       "is running",
	}
	cluster_infos := []ClusterInfo{pod1}
	err := responseJson(response, 0, "succ", cluster_infos)
	if err != nil {
		log.Errorf("[monitorInfoHandler] response err:%s", err.Error())
	}
}

// 节点扩缩容
func ClusterHandlerScalePods(response http.ResponseWriter, request *http.Request) {
	request.ParseForm()
	log.Infof("Conn scale pods. Form:%#v", request.Form)

	pod1 := ClusterInfo{
		SpiderName: "scale",
		NodeStatus: "1/1",
		RunStatus:  "Running",
		Age:        "6d",
		NodeAddr:   "123456",
		Desc:       "is running",
	}
	cluster_infos := []ClusterInfo{pod1}
	err := responseJson(response, 0, "succ", cluster_infos)
	if err != nil {
		log.Errorf("[monitorInfoHandler] response err:%s", err.Error())
	}
}

// 删除爬虫
func ClusterHandlerDeleteSpider(response http.ResponseWriter, request *http.Request) {
	request.ParseForm()
	log.Infof("Conn delete spider. Form:%#v", request.Form)

	pod1 := ClusterInfo{
		SpiderName: "scale",
		NodeStatus: "1/1",
		RunStatus:  "Running",
		Age:        "6d",
		NodeAddr:   "123456",
		Desc:       "is running",
	}
	cluster_infos := []ClusterInfo{pod1}
	err := responseJson(response, 0, "succ", cluster_infos)
	if err != nil {
		log.Errorf("[monitorInfoHandler] response err:%s", err.Error())
	}
}
